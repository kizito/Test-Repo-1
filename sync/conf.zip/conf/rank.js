function computeRank(selling, rating, review, numOfDays) {

	var sellInfo = parseFloat(selling);
	var ratingInfo = parseFloat(rating);
	var reviewInfo = parseFloat(review);
	var diffNumOfDays = parseInt(numOfDays);
	var tot = 0;
	if (sellInfo > 0) {
		if (sellInfo > 129,999) {
			tot = tot + 0.1
		} else { 
			tot = tot + (130000 - sellInfo) / 120000
		}
	}

	if (ratingInfo > 0) {
		if (ratingInfo <= 1) {
			tot = tot + 0
		} else {
			tot = tot + ratingInfo / 12
		}
	}

	if (reviewInfo > 0) {
		if (reviewInfo <= 3000) {
			tot = tot + 0.5
		} else {
			tot = tot + reviewInfo / 200
		}
	}

	if (diffNumOfDays > -1) {
		if (diffNumOfDays <= 100) {
			tot = tot + (1 - parseFloat(diffNumOfDays)/30);
		} 
	}

	if (tot >= 2)
		return 2
	else
		return tot;

}